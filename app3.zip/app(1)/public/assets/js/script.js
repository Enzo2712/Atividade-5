const form = document.querySelector("#cep-form");
const cepInput = document.querySelector("#cep");
const submitButton = document.querySelector("#consultar");
const message = document.querySelector("#mensagem");
const result = document.querySelector("#resultado");

const fields = {
	cep: document.querySelector("#valor-cep"),
	logradouro: document.querySelector("#valor-logradouro"),
	bairro: document.querySelector("#valor-bairro"),
	cidade: document.querySelector("#valor-cidade"),
	uf: document.querySelector("#valor-uf"),
	ibge: document.querySelector("#valor-ibge"),
	ddd: document.querySelector("#valor-ddd"),
};

function showMessage(text = "", state = "") {
	message.textContent = text;
	if (state) {
		message.dataset.state = state;
	} else {
		delete message.dataset.state;
	}
}

function hideResult() {
	result.hidden = true;
}

function showAddress(address) {
	fields.cep.textContent = address.cep || "Não informado";
	fields.logradouro.textContent = address.logradouro || "Não informado";
	fields.bairro.textContent = address.bairro || "Não informado";
	fields.cidade.textContent = address.localidade || "Não informado";
	fields.uf.textContent = address.uf || "Não informado";
	fields.ibge.textContent = address.ibge || "Não informado";
	fields.ddd.textContent = address.ddd || "Não informado";
	result.hidden = false;
}

cepInput.addEventListener("input", () => {
	const digits = cepInput.value.replace(/\D/g, "").slice(0, 8);
	cepInput.value = digits.length > 5
		? `${digits.slice(0, 5)}-${digits.slice(5)}`
		: digits;
});

form.addEventListener("reset", () => {
	hideResult();
	showMessage();
});

form.addEventListener("submit", async (event) => {
	event.preventDefault();
	const cep = cepInput.value.replace(/\D/g, "");
	hideResult();

	if (cep.length !== 8) {
		showMessage("Digite um CEP válido com 8 números.", "error");
		cepInput.focus();
		return;
	}

	submitButton.disabled = true;
	showMessage("Consultando CEP…", "loading");

	try {
		const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
		if (!response.ok) {
			throw new Error("Não foi possível acessar o serviço de CEP.");
		}

		const address = await response.json();
		if (address.erro) {
			showMessage("CEP não encontrado. Confira os números e tente novamente.", "error");
			return;
		}

		showAddress(address);
		showMessage("Endereço encontrado.", "success");
	} catch (error) {
		showMessage(
			error instanceof TypeError
				? "Não foi possível conectar ao serviço. Verifique sua internet e tente novamente."
				: error.message,
			"error",
		);
	} finally {
		submitButton.disabled = false;
	}
});
